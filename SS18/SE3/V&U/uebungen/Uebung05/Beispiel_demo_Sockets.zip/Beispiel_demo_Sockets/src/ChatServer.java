import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {
	public ChatServer(int port) throws IOException {
		ServerSocket server = new ServerSocket(port);
		while (true) { // akzeptiere Requests - erzeuge Clientsocket
			Socket client = server.accept();
			// lese Namen des Client
			BufferedReader in = new BufferedReader(new InputStreamReader(client
					.getInputStream()));
			String cName = in.readLine();
			System.out.println("New client " + cName + " from "
					+ client.getInetAddress());
			/* erzeuge Handler-Objekt f�r jeden neuen Client und starte dessen Thread*/
			ChatHandler c = new ChatHandler(cName, client);
			c.start();
		}
	}

	public static void main(String args[]) throws IOException {
		int port = 4711;
		System.out.println("Chat-Server is listening at port " + port);
		new ChatServer(port);
	}
}
