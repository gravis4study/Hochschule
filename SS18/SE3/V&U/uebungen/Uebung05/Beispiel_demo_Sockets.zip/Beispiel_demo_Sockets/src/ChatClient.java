import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ChatClient {
	public ChatFrame gui;

	private Socket socket;

	private BufferedReader in;

	private PrintWriter out;

	public ChatClient(String name, String server, int port) {
		/* GUI erzeugen und Events behandeln:
		 Nach Texteingaben wird    sendTextToChat(),
		 bei Schlie�en des Fensters disconnect() aufgerufen.*/
		gui = new ChatFrame(name + " - Chat mit Sockets");
		gui.input.addKeyListener(new EnterListener(this, gui));
		gui.addWindowListener(new ExitListener(this));

		// Socket erzeugen, am Server anmelden und lauschen
		try {
			socket = new Socket(server, port);
			in = new BufferedReader(new InputStreamReader(socket
					.getInputStream()));
			out = new PrintWriter(socket.getOutputStream(), true);
			// anmelden des neuen Client bei Server
			out.println(name);
			// wartet auf Eingaben anderer Chat-Clients
			while (true) {
				gui.output.append("\n" + in.readLine());
			}
		} catch (Exception e) {
		}
	}

	// wird von KeyListener aufgerufen
	protected void sendTextToChat(String str) {
		out.println(str);
	}

	// wird von WindowListener aufgerufen
	protected void disconnect() {
		try {

			socket.close();

		} catch (IOException e) {
			//handle Exception
		}
	}

	public static void main(String args[]) throws IOException {
		// Aufruf: java ChatClient daisy nbkoschel 4711
		int port = Integer.parseInt(args[2]);
		//FIXME falsche Folie folgende 2 Zeilen falsch
		//		String host =Integer.parseInt(args[1]);
		//		String name =Integer.parseInt(args[0]);
		String host = args[1];
		String name = args[0];
		ChatClient c = new ChatClient(name, host, port);
	}
}
