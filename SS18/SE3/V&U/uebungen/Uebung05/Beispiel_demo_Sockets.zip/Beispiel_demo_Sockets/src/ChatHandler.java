import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Enumeration;
import java.util.Vector;

public class ChatHandler extends Thread {
	Socket socket;

	String name;

	BufferedReader in;

	PrintWriter out; // statisch !alle Handler f�r broadcast

	protected static Vector handlers = new Vector();

	public ChatHandler(String name, Socket socket) throws IOException {
		this.name = name;
		this.socket = socket;
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
		out = new PrintWriter(socket.getOutputStream(), true);
	}

	public void run() {
		try {
			broadcast(name + " entered");// f�hrt broadcast f�r Anmeldung durch
			handlers.addElement(this);// f�gt Handler hinzu
			while (true) {
				String message = in.readLine();// liest Eingabe von seinem Client
				if (message == null) {
					break;
				}
				broadcast(name + ": " + message); // broadcast der Eingabe
                System.out.println(name + ": " + message);
			}
		} catch (IOException ex) {
			//handle Exception
		} finally {
			// Thread beendet
			handlers.removeElement(this);
			broadcast(name + " left");
			try {
				socket.close();
			} catch (IOException ex) {
				//handle Exception
			}
		}
	}

	protected static void broadcast(String message) {
		synchronized (handlers) {
			Enumeration e = handlers.elements();
			while (e.hasMoreElements()) {
				ChatHandler handler = (ChatHandler) e.nextElement();
				//TODO remove try catch from slide
				handler.out.println(message);
				handler.out.flush();

			}
		}
	}
}
