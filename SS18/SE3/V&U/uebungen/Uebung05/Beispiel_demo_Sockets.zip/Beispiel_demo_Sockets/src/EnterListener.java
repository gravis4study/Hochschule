import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class EnterListener extends KeyAdapter {
	ChatClient client;

	ChatFrame gui;

	public EnterListener(ChatClient client, ChatFrame gui) {
		this.client = client;
		this.gui = gui;
	}

	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ENTER) { // sende eingegebenen Text an Client
			client.sendTextToChat(gui.input.getText());
			gui.input.setText(""); // leere Eingabefeld in gui
		}
	}
}
