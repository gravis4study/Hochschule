Dies ist eine Demo zu Sockets

Es handelt sich hierbei um eine Demonstration der Verwendung von Sockets im Szenario "Chat-System".

1. In "setEnvironment.cmd" muss evtl. die Variable JAVA_HOME angepasst werden
2. Kompilieren Sie alle Klassen aus dem Verzeichnis ".\src"
3. Server in eigener Konsole starten:
	Der Server lauscht standardm��ig auf Port 4711 und wird
	ohne Parameter gestartet.
4. Ersten Client in eigener Konsole starten
5. Zweiten Client in eigener Konsole starten

	Clients m�ssen mit 3 Argumenten aufgerufen werden:
		arg[0]= Name des Chatters (beliebiger String)
		arg[1]= IP des Servers (host) (wenn der Server und der Client auf einem Rechner laufen: 127.0.0.1)
		arg[2]= Port, auf dem der Server lauscht (standardm��ig 4711)
6. Es kann mit den beiden Clients gechattet werden.
X. R�umt die erzeugten Klassendateien wieder auf.

Viel Freude!