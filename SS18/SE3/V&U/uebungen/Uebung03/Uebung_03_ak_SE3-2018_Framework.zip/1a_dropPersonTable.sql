drop table PERSON
/

