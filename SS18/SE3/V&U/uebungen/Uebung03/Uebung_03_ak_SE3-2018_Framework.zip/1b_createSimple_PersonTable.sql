-- ============================================================
--   Table: PERSON  
============================================================
create table PERSON
(
    PERS_ID     VARCHAR2(40)           not null,
    NAME        VARCHAR2(20)           null    ,
    VORNAME     VARCHAR2(20)           null    ,
    GEBURTSTAG  DATE                   null    ,
    constraint PK_PERSON primary key (PERS_ID)
);

create sequence myID;
