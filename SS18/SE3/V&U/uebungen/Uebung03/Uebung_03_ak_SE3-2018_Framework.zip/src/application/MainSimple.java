package application;

import de.fhhannover.inform.persistence.*;
import java.sql.Date;
import java.util.Vector;

public class MainSimple {

  public static void main(String[] args) {
    try{

      // Java-Objekt erzeugen
      Person p2 = new Person();   //setzt automatisch die Oid
      p2.setName("Commander", "Scott");
      p2.setGeburtstag(new Date(68,11,9));
      System.out.println(p2);
      Transaction t2 = new Transaction();
      t2.addObject(p2);
      t2.transactionCommit();

      // Alle Personen ausgeben
      Vector v =  PersonDbBroker.exemplar().searchByName("");
      Person pIt;
      for (int i=0; i < v.size(); i++)  {
        pIt = (Person)v.get(i);
        System.out.println(pIt);
      }

    }
    catch (Exception e) {e.printStackTrace();}
  }
}
