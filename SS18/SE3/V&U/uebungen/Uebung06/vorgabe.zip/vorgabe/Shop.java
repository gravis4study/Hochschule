import java.util.Hashtable;

public class Shop {
    Hashtable hash = new Hashtable();

    public void buyProduct(String id, Person buyer) {
        Product p = (Product)hash.get(id);
        buyer.addToBill(p.getPrice());
    }

    public void setProduct(Product p) {
        hash.put(p.getId(), p);
    }

    public Shop() {
        this.setProduct(new Product("1", "Brot", 3.50));
        this.setProduct(new Product("2", "Bier", 8.75));
        this.setProduct(new Product("3", "Wein", 4.98));
        this.setProduct(new Product("4", "Kartoffeln", 4.21));
        this.setProduct(new Product("5", "Kaffee", 4.70));
    }

    public static void main(String[] args) {
        Shop shop = new Shop();
    }
}
