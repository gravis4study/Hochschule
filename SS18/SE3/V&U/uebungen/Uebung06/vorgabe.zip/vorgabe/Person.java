public class Person {
    public Person(String name) {
        this.name = name;
    }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public double getBill() { return bill; }

    public void addToBill(double amount) { this.bill += amount; }

    private String name;
    private double bill;
}
