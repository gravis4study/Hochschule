public class Shopping {
    public static void main(String[] args) {
        Person p = new Person("Daisy Duck");
        Shop s = new Shop();
        s.buyProduct("1", p);
        s.buyProduct("2", p);
        System.out.println("Summe = " + p.getBill());
    }
}
