import java.rmi.Naming;

public class RmiClient {

	public static void main(String[] args) {
		try {

			String remoteObjId = "//localhost/myRemoteRefObj";
			Hello obj = (Hello) Naming.lookup("rmi:" + remoteObjId);
			String message = obj.sayHello("Client-Eingabe-String");
			System.out.println("Ergebnis vom Server: \t"+ message);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
