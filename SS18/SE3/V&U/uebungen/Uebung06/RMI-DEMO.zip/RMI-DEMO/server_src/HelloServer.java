import java.rmi.Naming;

public class HelloServer {

	public static void main(String args[]) {

		try {
			// erzeuge Objekt fuer Remote Zugriff
			HelloImpl obj = new HelloImpl();
			System.out.println("HelloServer: hat Objekt remoteHello erzeugt");
			// registriere das Objekt obj unter dem Namen "myRemoteRefObj"
			// unter diesem Namen kann ein Client auf das Objekt zugreifen
			String remoteObjId = "//localhost/myRemoteRefObj";
			Naming.rebind(remoteObjId, obj);

			System.out.println("HelloServer: " + remoteObjId
					+ " in registry per rebind registriert");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
